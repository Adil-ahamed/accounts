// import axios from 'axios';
import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';

import Table from '@mui/material/Table';
import Paper from '@mui/material/Paper';
import Dialog from '@mui/material/Dialog';
import TableRow from '@mui/material/TableRow';
import TableHead from '@mui/material/TableHead';
import TableCell from '@mui/material/TableCell';
import TableBody from '@mui/material/TableBody';
import TableContainer from '@mui/material/TableContainer';
import { Box, Stack, Button, TextField } from '@mui/material';

// import { base, redirectUrl } from 'src/config';

import Iconify from 'src/components/iconify';

import Divisions from './components/Divisions';
import CustomerOrPurchase from './components/CustomerOrPurchase';

// const GET_TAX = '/getCompanyTaxCommon';

function ReceiptTable({ typ, headerData, tableData, setTableData }) {
  // const [masterData, setMasterData] = useState([]);
  const [open, setOpen] = React.useState(false);
  const [narModal, setNarModal] = useState(false);
  const [searchVal, setSearchVal] = useState('');
  const [acName, setAcName] = useState([]);
  const [arrIndex, setArrIndex] = useState(0);
  const [vhrNo, setVhrNo] = useState(0);
  // const [tax, setTax] = useState(0);
  const [division, setDivision] = useState([]);
  const [modalTyp, setModalTyp] = useState('ledger');

  const addRow = () => {
    const newRow = {
      vNo: 0,
      accountName: '',
      division: '',
      amount: 0,
      vat: 0,
      vatAmt: 0,
      netTotal: 0,
      match: '',
      narration: '',
    };

    setTableData([...tableData, newRow]);
  };

  // const handleClickOpen = () => {
  //   setOpen(true);
  // };
  // useEffect(() => {
  //   const fetchTax = () => {
  //     axios
  //       .get(`${base}${GET_TAX}`, { withCredentials: true })
  //       .then((res) => {
  //         setTax(res.data.data);
  //         setTableData([{ vat: res.data.data }]);
  //         // Handle the response data, for example:
  //       })
  //       .catch((err) => {
  //         if (err.response.status === 401 || err.response.status === 403) {
  //           window.location.href = redirectUrl;
  //         }
  //       });
  //   };

  //   fetchTax();
  // }, []);

  useEffect(() => {
    const getLedger = () => {
      setVhrNo(headerData[3]?.[0]?.vhr_no || 0);
      // setMasterData(headerData);
      setAcName(headerData[1]);
      // setTax(headerData[5][0]?.tax || 0);
    };

    getLedger();
  }, [headerData.length, headerData]);

  const handleParty = (e, index, modal) => {
    setModalTyp(modal);
    setArrIndex(index);
    setSearchVal(e.target.value);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleCloseNar = () => {
    setNarModal(false);
  };
  const handleNarrOpen = (index) => {
    setArrIndex(index);
    setNarModal(true);
  };
  const handleNarrtion = (e) => {
    setTableData((prevRows) =>
      prevRows.map((row, i) => (i === arrIndex ? { ...row, narration: e.target.value } : row))
    );
  };
  const handleVatChange = (e, index) => {
    const vatP = Number(e.target.value);
    const taxAmtValue = (vatP / 100) * tableData[index].amount;
    const taxAmt = Number(taxAmtValue);
    const total = Number(taxAmt + tableData[index].amount);
    setTableData((prevRows) =>
      prevRows.map((row, i) =>
        i === index ? { ...row, vat: vatP, vatAmt: taxAmt, netTotal: total } : row
      )
    );
  };
  const handleAmountChange = (e, index) => {
    const value = Number(e.target.value);
    const taxAmtValue = (tableData[index].vat / 100) * value;
    const taxAmt = Number(taxAmtValue);
    const total = Number(taxAmt + value);
    setTableData((prevRows) =>
      prevRows.map((row, i) =>
        i === index ? { ...row, amount: value, vatAmt: taxAmt, netTotal: total } : row
      )
    );
  };
  return (
    <div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        {modalTyp === 'ledger' ? (
          <CustomerOrPurchase
            searchVal={searchVal}
            onClose={handleClose}
            acName={acName}
            index={arrIndex}
            setTableData={setTableData}
            setDivision={setDivision}
          />
        ) : (
          <Divisions
            searchVal={searchVal}
            onClose={handleClose}
            index={arrIndex}
            division={division}
            setTableData={setTableData}
          />
        )}
      </Dialog>
      <Dialog
        open={narModal}
        onClose={handleCloseNar}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <Box sx={{ width: 450, p: 2 }}>
          <TextField
            multiline
            rows={4}
            size="small"
            fullWidth
            label="Narration"
            placeholder="type something"
            variant="outlined"
            value={tableData[arrIndex]?.narration || ''}
            onChange={handleNarrtion}
          />
          <Button sx={{ mt: 2 }} fullWidth variant="outlined" color="info" onClick={handleCloseNar}>
            {' '}
            Close
          </Button>
        </Box>
      </Dialog>
      <Stack direction="row" justifyContent="end" sx={{ mb: 1 }}>
        <Button
          startIcon={<Iconify icon="mingcute:add-fill" />}
          variant="contained"
          color="success"
          onClick={addRow}
        >
          New cell
        </Button>
      </Stack>
      <TableContainer component={Paper} sx={{ height: '100%' }}>
        <Table sx={{ minWidth: 1050 }} aria-label="simple table" size="small">
          <TableHead>
            <TableRow sx={{ bgcolor: '#327161', color: '#ffff' }}>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="70px">
                Voucher no
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="150px" align="left">
                Account Name
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="150px" align="left">
                Division
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="100px" align="left">
                Amount
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="100px" align="left">
                VAT
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="100px" align="left">
                VAT Amt
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="100px" align="left">
                Net total
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="100px" align="left">
                Match
              </TableCell>
              <TableCell sx={{ bgcolor: '#327161', color: '#ffff' }} width="100px" align="left">
                Narration
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {tableData.map((row, index) => (
              <TableRow key={index} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell sx={{ px: 2, py: 0.5 }} component="th" scope="row">
                  {/* {row.vNo} */}
                  {vhrNo + index}
                </TableCell>
                <TableCell sx={{ px: 0.5, py: 0.5 }} align="left">
                  <TextField
                    onChange={(e) => handleParty(e, index, 'ledger')}
                    size="small"
                    id={`accountName-${index}`}
                    fullWidth
                    value={row.accountName}
                    placeholder="Ledger"
                    variant="outlined"
                  />
                </TableCell>
                <TableCell sx={{ px: 0.5, py: 0.5 }} align="left">
                  <TextField
                    disabled={division.length < 1}
                    size="small"
                    value={row.division}
                    onChange={(e) => handleParty(e, index, 'division')}
                    id={`division-${index}`}
                    fullWidth
                    placeholder="Division"
                    variant="outlined"
                  />
                </TableCell>
                <TableCell sx={{ px: 0.5, py: 0.5 }} align="left">
                  <TextField
                    size="small"
                    id={`amount-${index}`}
                    fullWidth
                    onChange={(e) => handleAmountChange(e, index)}
                    value={row.amount}
                    placeholder="Amount"
                    type="number"
                    variant="outlined"
                  />
                </TableCell>
                <TableCell sx={{ px: 0.5, py: 0.5 }} align="left">
                  {/* {row.vat} */}
                  <TextField
                    size="small"
                    id={`amount-${index}`}
                    fullWidth
                    type="number"
                    onChange={(e) => handleVatChange(e, index)}
                    value={row.vat}
                    placeholder="Amount"
                    variant="outlined"
                  />
                </TableCell>
                <TableCell sx={{ px: 0.5, py: 0.5 }} align="left">
                  {row.vatAmt.toFixed(3)}
                </TableCell>
                <TableCell sx={{ px: 0.5, py: 0.5 }} align="left">
                  {row.netTotal.toFixed(3)}
                </TableCell>
                <TableCell sx={{ px: 0.5, py: 0.5 }} align="left">
                  <Button>Match</Button>
                </TableCell>
                <TableCell sx={{ px: 2, py: 0.5 }} align="left">
                  <Button onClick={() => handleNarrOpen(index)}>Narration</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
}

ReceiptTable.propTypes = {
  typ: PropTypes.string.isRequired,
  headerData: PropTypes.array,
  tableData: PropTypes.func,
  setTableData: PropTypes.func,
};

export default ReceiptTable;
