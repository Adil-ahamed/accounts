import axios from 'axios';
import dayjs from 'dayjs';
import PropTypes from 'prop-types';
import React, { lazy, Suspense, useState, useEffect, useCallback } from 'react';

import Skeleton from '@mui/material/Skeleton';
import TextField from '@mui/material/TextField';
import IconButton from '@mui/material/IconButton';
import Autocomplete from '@mui/material/Autocomplete';
import useMediaQuery from '@mui/material/useMediaQuery';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { Box, Grid, Paper, Stack, Button, Typography } from '@mui/material';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';

import LoaderDrop from 'src/utils/LoaderDrop';
import AlertDialog from 'src/utils/AlertDialog';

import { baseUrl, redirectUrl } from 'src/config';
import { useSnackbar } from 'src/context/SnackBarContext';

import Iconify from 'src/components/iconify/iconify';

const ReceiptTable = lazy(() => import('./ReceiptTable'));

// --------- APIs ---------//
const HEADER_API = '/getAccountMaster';
const SUBMIT_API = '/addPaymentReceipt';
const RECEIPT_ID_API = '/getReceiptPaymentById';
const DELETE_API = '/deleteReceiptPaymentById';

function Receipt({ typ }) {
  const { showSnackbar } = useSnackbar();
  const isSmallScreen = useMediaQuery('(max-width:768px)');
  const [headerData, setHeaderData] = useState([]);
  const [recNo, setRecNo] = useState(0);
  const [loading, setLoading] = useState(false);
  const [alertOpen, setAlerOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [data, setData] = useState({
    branch: null,
    staff: null,
    CB: null,
    date: dayjs(),
    bankNar: '',
    voucherNo: 0,
    receiptNo: 0,
    amount: 0,
    mode: '',
    table: [],
  });
  const [tableData, setTableData] = useState([
    {
      vNo: 0,
      accountName: '',
      division: '',
      amount: 0,
      vat: 0,
      vatAmt: 0,
      netTotal: 0,
      match_inv: '',
      narration: '',
    },
  ]);
  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${baseUrl}${HEADER_API}`, { withCredentials: true });
      if (response?.data?.data) {
        const def_branch = response?.data.data[0].find((item) => item.default_val === 1);
        const def_staff = response?.data.data[2].find((item) => item.label === 'Admin');
        setData((prevState) => ({
          ...prevState,
          branch: def_branch,
          staff: def_staff,
          voucherNo: response?.data?.data[3][0]?.vhr_no,
          receiptNo: response?.data?.data[3][0]?.rec_no,
        }));
        setRecNo(response?.data?.data[3][0]?.rec_no);
        setHeaderData(response?.data?.data);
        setLoading(false);
      }
    } catch (error) {
      showSnackbar('Something went wrong', 'error');
      if (error.response.status === 401 || error.response.status === 403) {
        window.location.href(redirectUrl);
      }
    }
  }, [showSnackbar]);
  useEffect(() => {
    fetchData();
  }, [fetchData]);
  // const handleVoucher = (e) => {
  //   setData((prevState) => ({ ...prevState, voucherNo: e.target.value }));
  // };
  const handleReceipt = (e) => {
    handleReceiptId(e.target.value);
    setData((prevState) => ({ ...prevState, receiptNo: e.target.value }));
  };

  const incrementReceipt = () => {
    if (data.receiptNo + 1 <= recNo) {
      setData((prevState) => ({ ...prevState, receiptNo: prevState.receiptNo + 1 }));
      handleReceiptId(data.receiptNo + 1);
    } else {
      showSnackbar('Receipt not available', 'warning');
    }
  };
  const handleReceiptId = (no) => {
    setLoading(true);
    axios
      .post(`${baseUrl}${RECEIPT_ID_API}`, { rec_no: no }, { withCredentials: true })
      .then((res) => {
        // if (res.data.data === 'NO_DATA') {
        //   handleAfterSubmission();
        // }
        if (res.data.success) {
          if (res.data.data[1] > 0) {
            setTableData(res?.data?.data[1]);
          }
          const item = res.data.data[0][0];
          const find_branch = headerData[0].find((value) => value.label === item.branch);
          const find_staff = headerData[2].find((value) => value.label === item.staff);
          const find_cb = headerData[4].find((value) => value.label === item.account);
          setData((prevData) => ({
            ...prevData,
            branch: find_branch,
            staff: find_staff,
            CB: find_cb,
            date: dayjs(item.date),
            bankNar: item.narration,
            voucherNo: item.vhr_no,
            receiptNo: item.rec_no,
            amount: item.amount,
            mode: item.mode,
          }));
        } else {
          showSnackbar('Something went wrong, Refresh this page', 'error');
        }
      })
      .catch((err) => {
        if (err.response.status === 401 || err.response.status === 403) {
          window.location.href = redirectUrl;
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };
  const decrementReceipt = () => {
    handleReceiptId(data.receiptNo - 1);
    setData((prevState) => ({ ...prevState, receiptNo: Math.max(0, prevState.receiptNo - 1) }));
  };

  const onSubmit = () => {
    setLoading(true);
    data.table = tableData;
    data.mode = typ;
    axios
      .post(`${baseUrl}${SUBMIT_API}`, { data }, { withCredentials: true })
      .then((res) => {
        if (res.data) {
          setLoading(false);
        }
        if (res.data.success) {
          handleAfterSubmission();
          console.log(res.data);
          showSnackbar(res.data.message, 'success');
        } else {
          showSnackbar('Something went wrong, Refresh this page', 'error');
        }
      })
      .catch((err) => {
        if (err.response.status === 401 || err.response.status === 403) {
          window.location.href = redirectUrl;
        }
      });
  };

  const handleAfterSubmission = () => {
    fetchData();
    setLoading(true);
    setAlerOpen(false);
    setData((prevState) => ({
      ...prevState,
      CB: null,
      table: [],
      amount: 0,
      date: dayjs(),
      bankNar: '',
    }));
    setTableData([
      {
        accountName: '',
        division: '',
        amount: 0,
        vat: 0,
        vatAmt: 0,
        netTotal: 0,
        match_inv: '',
        narration: '',
      },
    ]);
    setLoading(false);
  };
  const askPrint = () => {
    console.log('print');
  };
  const handleDelete = async () => {
    setLoading(true);
    axios
      .delete(baseUrl + DELETE_API, {
        data: { rec_no: data.receiptNo }, // You should pass the data in the request body, not as a query parameter
        withCredentials: true,
      })
      .then((res) => {
        setLoading(false);
        if (res.data.success) {
          showSnackbar(`${data.receiptNo} This ${typ} deleted`, 'success');
          handleAfterSubmission();
          setDeleteOpen(false);
        } else if (res.data.data > 0) {
          console.log('here');
        } else {
          showSnackbar('Something went wrong, Refresh this page', 'error');
        }
      })
      .catch((err) => {
        console.log(err);
        if (err.response.status === 401 || err.response.status === 403) {
          // window.location.href = redirectUrl;
        }
      })
      .finally(() => {
        setLoading(false);
      });
  };

  return (
    <>
      <AlertDialog
        open={alertOpen}
        // onClose={handleCloseAlert}
        onConfirm={askPrint}
        onCancel={handleAfterSubmission}
        title="Print"
        message={`Do you want to print this ${typ}`}
        buttonType="info"
        buttonText="Print"
      />
      <AlertDialog
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        onConfirm={handleDelete}
        onCancel={() => setDeleteOpen(false)}
        title="Delete"
        message={`Do you want to delete this ${typ}`}
        buttonType="error"
        buttonText="Delete"
      />
      <LoaderDrop start={loading} />
      {/* <Typography sx={{ mt: 4 }} variant="body1" gutterBottom>
        Receipt
      </Typography> */}
      {isSmallScreen && (
        <Typography sx={{ mt: 2 }} variant="h4" textTransform="capitalize" gutterBottom>
          {typ}
        </Typography>
      )}
      <Box sx={{ p: 3 }} component={Paper}>
        <Stack direction="row">
          <Box maxWidth={!isSmallScreen ? 'md' : '100%'}>
            <Grid container spacing={2}>
              {headerData[0] && (
                <Grid item xs={6} sm={3}>
                  <Autocomplete
                    size="small"
                    id="combo-box-demo"
                    value={data.branch}
                    // isOptionEqualToValue={(options, value) => options.label === value.label}
                    getOptionSelected={(options, value) => options.id === value.id}
                    onChange={(event, value) => setData({ ...data, branch: value })}
                    options={headerData[0]}
                    renderInput={(params) => <TextField {...params} label="Branch" />}
                  />
                </Grid>
              )}
              {headerData[2] && (
                <Grid item xs={6} sm={3}>
                  <Autocomplete
                    size="small"
                    id="combo-box-demo"
                    value={data.staff}
                    // isOptionEqualToValue={(options, value) => options.label === value.label}
                    getOptionSelected={(options, value) => options.id === value.id}
                    onChange={(event, value) => setData({ ...data, staff: value })}
                    options={headerData[2]}
                    renderInput={(params) => <TextField {...params} label="Staff" />}
                  />
                </Grid>
              )}
              <Grid item xs={6} sm={3}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    format="DD/MM/YYYY"
                    value={data.date}
                    label="Date"
                    slotProps={{ textField: { fullWidth: true, size: 'small' } }}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={6} sm={3}>
                <TextField
                  size="small"
                  id="outlined-basic"
                  fullWidth
                  // onChange={handleVoucher}
                  label="Voucher No"
                  value={data?.voucherNo}
                  variant="outlined"
                  type="number"
                  inputProps={{
                    inputMode: 'numeric',
                    min: 0,
                    max: 100,
                    style: { textAlign: 'center' },
                  }}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                {headerData[4] && (
                  <Autocomplete
                    size="small"
                    id="combo-box-demo"
                    value={data.CB}
                    options={headerData[4]}
                    // isOptionEqualToValue={(options, value) => options.label === value.label}
                    getOptionSelected={(options, value) => options.id === value.id}
                    onChange={(event, value) => setData({ ...data, CB: value })}
                    renderInput={(params) => <TextField {...params} label="Cash/Bank" />}
                  />
                )}
              </Grid>

              <Grid item xs={12} sm={6}>
                <TextField
                  size="small"
                  id="outlined-basic"
                  fullWidth
                  label="Bank Narration"
                  variant="outlined"
                />
              </Grid>
            </Grid>

            <Grid container spacing={2} sx={{ pt: 2 }}>
              <Grid item xs={12} sm={5} md={4} display="flex" alignItems="center">
                <IconButton color="success" onClick={decrementReceipt}>
                  <Iconify icon="ant-design:minus-circle-outlined" sx={{ width: 35, height: 35 }} />
                </IconButton>
                <TextField
                  size="small"
                  id="outlined-basic"
                  // label="Receipt No"
                  onChange={handleReceipt}
                  type="number"
                  fullWidth
                  value={data?.receiptNo}
                  variant="outlined"
                  inputProps={{
                    style: { textAlign: 'center' },
                    min: 1,
                    max: recNo,
                    typeof: 'number',
                  }}
                />
                <IconButton color="success" onClick={incrementReceipt}>
                  <Iconify icon="ant-design:plus-circle-outlined" sx={{ width: 35, height: 35 }} />
                </IconButton>
              </Grid>

              <Grid item xs={12} sm={4}>
                <TextField
                  id="icons8:minus"
                  size="small"
                  fullWidth
                  label="Amount"
                  variant="outlined"
                />
              </Grid>
            </Grid>
          </Box>
          {!isSmallScreen && (
            <Box width={180}>
              {typ !== 'PAYMENT' ? (
                <img src="assets/images/FinaAcc/Receipt.png" alt="dsf" />
              ) : (
                <img src="assets/images/FinaAcc/Payment.png" alt="dsf" />
              )}
            </Box>
          )}
        </Stack>
      </Box>
      <Box sx={{ mt: 1 }}>
        <Suspense fallback={<Skeleton variant="rectangular" width="100%" height={140} />}>
          <ReceiptTable
            typ={typ}
            headerData={headerData}
            tableData={tableData}
            setTableData={setTableData}
          />
        </Suspense>
      </Box>
      <Grid container sx={{ mt: 0 }} spacing={3}>
        <Grid item xs={4}>
          <Button variant="contained" fullWidth color="success" onClick={onSubmit}>
            Save
          </Button>
        </Grid>
        <Grid item xs={4}>
          <Button variant="contained" fullWidth color="info" disabled={data.receiptNo === recNo}>
            Print
          </Button>
        </Grid>
        <Grid item xs={4}>
          <Button variant="contained" fullWidth color="secondary">
            Attach
          </Button>
        </Grid>
        <Grid item xs={4}>
          <Button variant="contained" fullWidth color="warning" onClick={handleAfterSubmission}>
            Clear
          </Button>
        </Grid>
        <Grid item xs={4}>
          <Button
            variant="contained"
            fullWidth
            color="error"
            disabled={data.receiptNo === recNo}
            onClick={() => setDeleteOpen(true)}
          >
            Delete
          </Button>
        </Grid>
      </Grid>
    </>
  );
}
Receipt.propTypes = {
  typ: PropTypes.string.isRequired,
};

export default Receipt;
