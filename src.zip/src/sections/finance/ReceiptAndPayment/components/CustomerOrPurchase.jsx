import axios from 'axios';
import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';

import { DataGrid } from '@mui/x-data-grid';
import TextField from '@mui/material/TextField';

import { redirectUrl, baseUrlTrvel } from 'src/config';

const columns = [
  { field: 'id', headerName: 'ID', width: 70 },
  { field: 'label', headerName: 'Account Name', width: 200 },
  { field: 'Typ', headerName: 'Under', width: 130 },
];

const GET_DIVISION = '/getdivisions';
function CustomerOrPurchase({ searchVal, onClose, acName, index, setTableData, setDivision }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredRows, setFilteredRows] = useState([]);

  useEffect(() => {
    if (searchVal !== '') {
      setSearchTerm(searchVal);
    }
  }, [searchVal]);

  useEffect(() => {
    if (acName) {
      const filteredData = searchTerm
        ? acName.filter(
            (row) => row.label && row.label.toLowerCase().includes(searchTerm.toLowerCase())
          )
        : acName;
      setFilteredRows(filteredData);
    }
  }, [acName, searchTerm]);

  const handleRowClick = (params) => {
    if (params.row.division === 'YES') {
      setTableData((prevRows) =>
        prevRows.map((row, i) => (i === index ? { ...row, accountName: params.row.label } : row))
      );
      onClose();
    } else {
      axios
        .post(baseUrlTrvel + GET_DIVISION, { id: 1003 }, { withCredentials: true })
        .then((res) => {
          if (res.data.success) {
            setTableData((prevRows) =>
            prevRows.map((row, i) => (i === index ? { ...row, accountName: params.row.label } : row))
          );
            setDivision(res.data.data);
            onClose();
          }
        })
        .catch((err) => {
          console.log(err);
          if (err.response.status === 401 || err.response.status === 403) {
            window.location.href = redirectUrl;
          }
        });
    }
  };
  return (
    <div style={{ height: 600, maxWidth: 600, padding: '10px' }}>
      <TextField
        label="Search"
        variant="outlined"
        fullWidth
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        sx={{ my: 1.5 }}
        autoFocus
      />
      {/* <DataGrid rows={filteredRows} columns={columns} onRowClick={handleRowClick} /> */}
      <DataGrid rows={filteredRows} columns={columns} onRowClick={handleRowClick} />
    </div>
  );
}
CustomerOrPurchase.propTypes = {
  searchVal: PropTypes.string.isRequired,
  onClose: PropTypes.func.isRequired,
  acName: PropTypes.array,
  setTableData: PropTypes.func,
  setDivision: PropTypes.func,
  index: PropTypes.number.isRequired,
};

export default CustomerOrPurchase;
