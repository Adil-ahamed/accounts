import PropTypes from 'prop-types';
import React, { useState, useEffect } from 'react';

import { DataGrid } from '@mui/x-data-grid';
import TextField from '@mui/material/TextField';

const columns = [
  {
    field: '#',
    headerName: '#',
    width: 70,
    renderCell: (params) => params.api.getAllRowIds().indexOf(params.id) + 1,
  },
  { field: 'name1', headerName: 'Ledger name', width: 300 },
  { field: 'status_', headerName: 'Status', width: 160 },
];

function Divisions({ searchVal, onClose, index, division, setTableData }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredRows, setFilteredRows] = useState(division);
  useEffect(() => {
    if (searchVal !== '') {
      setSearchTerm(searchVal);
    }
  }, [searchVal]);
  useEffect(() => {
    // Filter rows based on the search term
    const filteredData = division.filter((row) =>
      row.name1.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredRows(filteredData);
  }, [division, searchTerm]);

  const handleRowClick = (params) => {
    setTableData((prevRows) =>
      prevRows.map((row, i) => (i === index ? { ...row, division: params.row.name1 } : row))
    );

    onClose();
  };
  return (
    <div style={{ height: 400, width: '100%', padding: '10px' }}>
      <TextField
        label="Search"
        variant="outlined"
        fullWidth
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{ marginBottom: '8px' }}
        autoFocus
      />
      <DataGrid rows={filteredRows} columns={columns} onRowClick={handleRowClick} />
    </div>
  );
}
Divisions.propTypes = {
  division: PropTypes.array.isRequired,
  index: PropTypes.number.isRequired,
  onClose: PropTypes.func.isRequired,
  searchVal: PropTypes.string.isRequired,
  setTableData: PropTypes.func,
};

export default Divisions;
