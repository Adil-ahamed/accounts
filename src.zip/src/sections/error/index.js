export { default as NotFoundView } from './not-found-view';
