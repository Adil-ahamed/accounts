import React from 'react';

import { Box, Stack, TextField, Autocomplete } from '@mui/material';

const top100Films = [{ label: 'The Shawshank Redemption', year: 1994 }];
function Sample() {
  return (
    <Box>
      <Stack direction="row">
        <Autocomplete
          disablePortal
          id="combo-box-demo"
          options={top100Films}
          sx={{ width: 300 }}
          renderInput={(params) => <TextField {...params} label="Movie" />}
        />
        <TextField label="dfsg" variant="outlined" />
        <TextField label="Ousdfgstlined" variant="outlined" />
        <TextField label="Osdfgsdfgutlined" variant="outlined" />
        <TextField label="Outtyrtylined" variant="outlined" />
      </Stack>
      <Stack direction="row">
        <Autocomplete
          disablePortal
          id="combo-box-demo"
          options={top100Films}
          sx={{ width: 300 }}
          renderInput={(params) => <TextField {...params} label="Movie" />}
        />
        <TextField label="Outldfgdfgined" variant="outlined" />
        <TextField label="Outlzxcvzxcvined" variant="outlined" />
        <TextField label="zzxcv" variant="outlined" />
        <TextField label="gasdf" variant="outlined" />
      </Stack>
    </Box>
  );
}

export default Sample;
