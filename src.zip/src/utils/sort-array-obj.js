export const sortByObjectName = (array, targetName) => {
    const sortedArray = [...array];
    // converth input value to lowercase and remove spaces if
    const inputName = targetName.trim().toLowerCase();
  
    sortedArray.sort((a, b) => {
      const nameA = a.name.trim().toLowerCase();
      const nameB = b.name.trim().toLowerCase();
  
      // Check for partial matches
      const partialMatchA = nameA.includes(inputName);
      const partialMatchB = nameB.includes(inputName);
  
      if (partialMatchA && !partialMatchB) {
        return -1; // Move partial match to the front
      }
      if (!partialMatchA && partialMatchB) {
        return 1; // Move partial match to the front
      }
  
      // If both are partial matches or both are not partial matches, compare alphabetically
      return nameA.localeCompare(nameB);
    });
  
    return sortedArray;
  };
  