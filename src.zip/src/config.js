export const exchangeKey = '21644dde67c1b416035c7d56';
const storedLgpath = localStorage.getItem('lgpath');



export const baseUrl = 'http://localhost:3008/account';
export const base = 'http://localhost:3008';
export const baseUrlTrvel = 'http://localhost:3008/travel';
export const homeUrl = 'http://localhost:5173/';
export const redirectUrl = storedLgpath
? `http://localhost:5173${storedLgpath}`
: 'http://localhost:5173/';

// export const homeUrl = 'http://app.wizzo.in:49200/';
// export const redirectUrl = storedLgpath ? `http://app.wizzo.in:49200${storedLgpath}` : 'http://app.wizzo.in:49200/';
// export const baseUrl = 'http://app.wizzo.in:49205/travel';
// export const baseUrlTrvel = 'http://localhost:3008/travel';