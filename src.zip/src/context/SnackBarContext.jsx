// SnackbarContext.js
import PropTypes from 'prop-types';
import React, { useMemo, useState, useContext, useCallback, createContext } from 'react';

import { Grid, Alert, Button, Snackbar } from '@mui/material';

const SnackbarContext = createContext();

export const useSnackbar = () => {
  const context = useContext(SnackbarContext);
  if (!context) {
    throw new Error('useSnackbar must be used within a SnackbarProvider');
  }
  return context;
};

export const SnackbarProvider = ({ children }) => {
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('info'); // Default severity is 'info'

  const showSnackbar = useCallback((message, severity = 'info') => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  }, []); // Empty dependency array as there are no external dependencies

  const hideSnackbar = useCallback(() => {
    setSnackbarOpen(false);
    setSnackbarMessage('');
  }, []);

  const value = useMemo(
    () => ({
      showSnackbar,
      hideSnackbar,
    }),
    [showSnackbar, hideSnackbar]
  );

  return (
    <>
      <SnackbarContext.Provider value={value}>{children}</SnackbarContext.Provider>
      <Snackbar
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        open={snackbarOpen}
        autoHideDuration={2000}
        onClose={hideSnackbar}
      >
        <Alert
          severity={snackbarSeverity}
          action={
            <Grid size="small" color="inherit" onClick={hideSnackbar}>
              <Button fontSize="small" />
            </Grid>
          }
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </>
  );
};

SnackbarProvider.propTypes = {
  children: PropTypes.any,
};

export default SnackbarProvider;
