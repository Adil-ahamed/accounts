import { Icon } from '@iconify/react';

// ----------------------------------------------------------------------

const icon = (name) => <Icon icon={name} fontSize={24} />;

const navConfig = [
  {
    title: 'dashboard',
    path: '/',
    icon: icon('ic:round-space-dashboard'),
  },
  {
    title: 'Finance ',
    icon: icon('material-symbols:finance-rounded'), 
    children: [
      {
        title: 'Receipt',
        path: '/receipt',
        icon: icon('fluent:receipt-32-regular'), 
      },
      {
        title: 'Payment',
        path: '/payment',
        icon: icon('mdi:account-payment-outline'), 
      },
      {
        title: 'Journal',
        path: '/user',
        // icon: icon('icon-park-outline:flight-safety'), 
      },
      {
        title: 'Debit Note',
        path: '/user',
        // icon: icon('icon-park-outline:flight-safety'), 
      },
      {
        title: 'Credit Note',
        path: '/user',
        // icon: icon('icon-park-outline:flight-safety'), 
      },
      {
        title: 'Ledger',
        path: '/user',
        // icon: icon('icon-park-outline:flight-safety'), 
      },
      {
        title: 'Outstanding',
        path: '/user',
        // icon: icon('icon-park-outline:flight-safety'), 
      },
    ],
  },
  {
    title: 'Accounts',
    icon: icon('lucide:computer'),
    children: [
      {
        title: 'Aging Report',
        path: '/outputVatReport',
        icon: icon('lucide:computer'),
      },
      {
        title: 'Day book',
        path: '/outputVatReport',
        icon: icon('lucide:computer'),
      },

      {
        title: 'Bank',
        path: '/outputVatReport',
        icon: icon('lucide:computer'),
      },
      {
        title: 'Statement of Accounts',
        path: '/outputVatReport',
        icon: icon('lucide:computer'),
      },

      {
        title: 'Trial Bal',
        path: '/outputVatReport',
        icon: icon('lucide:computer'),
      },
      {
        title: 'PNL',
        path: '/outputVatReport',
        icon: icon('lucide:computer'),
      },
      {
        title: 'Balance sheet',
        path: '/outputVatReport',
        icon: icon('lucide:computer'),
      },
    ],
  },
  {
    title: 'Reports',
    icon: icon('tabler:report-search'),
    children: [
      {
        title: 'output Vat Report',
        path: '/outputVatReport',
        icon: icon('heroicons-outline:receipt-tax'),
      },
    ],
  },
];

export default navConfig;
