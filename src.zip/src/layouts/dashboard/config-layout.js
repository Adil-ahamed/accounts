// ----------------------------------------------------------------------

export const HEADER = {
  H_MOBILE: 64,
  H_DESKTOP: 75,
  H_DESKTOP_OFFSET: 80 - 16,
};

export const NAV = {
  WIDTH: 260,
};
