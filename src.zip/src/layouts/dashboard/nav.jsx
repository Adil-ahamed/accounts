import PropTypes from 'prop-types';
import { Icon } from '@iconify/react';
import { useRef, useState, useEffect } from 'react';

import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Drawer from '@mui/material/Drawer';
import { alpha } from '@mui/material/styles';
import Accordion from '@mui/material/Accordion';
import Typography from '@mui/material/Typography';
import ListItemButton from '@mui/material/ListItemButton';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';

import { usePathname } from 'src/routes/hooks';
import { RouterLink } from 'src/routes/components';

import { useResponsive } from 'src/hooks/use-responsive';

import Scrollbar from 'src/components/scrollbar';

import { NAV } from './config-layout';
import navConfig from './config-navigation';

export default function Nav({ openNav, onCloseNav }) {
  const [expandedAccordion, setExpandedAccordion] = useState(null);
  const accordionRef = useRef(null);

  useEffect(() => {
    if (openNav && expandedAccordion) {
      const accordionNode = accordionRef.current;

      accordionNode.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
      });

      // Scroll down to the end of the opened accordion's children
      accordionNode.querySelector('.simplebar-content').scrollTop =
        accordionNode.querySelector('.simplebar-content').scrollHeight;
    }
  }, [openNav, expandedAccordion]);

  const pathname = usePathname();
  const upLg = useResponsive('up', 'lg');

  useEffect(() => {
    if (openNav) {
      onCloseNav();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pathname]);

  const renderAccount = (
    <Box
      sx={{
        my: 3,
        mx: 2.5,
        py: 2,
        px: 1,
        display: 'flex',
        borderRadius: 1.5,
        alignItems: 'center',
        color: (theme) => alpha(theme.palette.grey[800], 1),
        bgcolor: (theme) => alpha(theme.palette.success.lighter, 1),
      }}
    >
      <Box width="100%" sx={{ textAlign: 'center' }}>
        <Typography variant="subtitle2">Company Name</Typography>
        <Typography variant="body2" sx={{ color: 'text.secondary' }}>
          subname
        </Typography>
      </Box>
    </Box>
  );

  const renderMenu = (
    <Stack component="nav" spacing={0.5} sx={{ px: 2 }}>
      {navConfig.map((item) => (
        <NavItem key={item.title} item={item} setExpandedAccordion={setExpandedAccordion} />
      ))}
    </Stack>
  );

  const renderContent = (
    <Scrollbar
      sx={{
        bgcolor: (theme) => alpha(theme.palette.info.lighter,0.0),
        height: 1,
        '& .simplebar-content': {
          height: 1,
          display: 'flex',
          flexDirection: 'column',
        },
      }}
    >
      {renderAccount}
      <Box ref={accordionRef} sx={{ pb: 4 }}>
        {renderMenu}
      </Box>
      <Box sx={{ flexGrow: 1 }} />
    </Scrollbar>
  );

  return (
    <Box
      sx={{
        flexShrink: { lg: 0 },
        width: { lg: NAV.WIDTH },
      }}
    >
      {upLg ? (
        <Box
          sx={{
            height: 1,
            position: 'fixed',
            width: NAV.WIDTH,
            borderRight: (theme) => `dashed 1px ${theme.palette.divider}`,
          }}
        >
          {renderContent}
        </Box>
      ) : (
        <Drawer
          open={openNav}
          onClose={onCloseNav}
          PaperProps={{
            sx: {
              width: NAV.WIDTH,
            },
          }}
        >
          {renderContent}
        </Drawer>
      )}
    </Box>
  );
}

Nav.propTypes = {
  openNav: PropTypes.bool,
  onCloseNav: PropTypes.func,
};

function NavItem({ item, setExpandedAccordion }) {
  const pathname = usePathname();
  const active = item.path === pathname;
  const [expanded, setExpanded] = useState(false);

  const accordionRef = useRef(null);

  const handleToggleAccordion = () => {
    setExpandedAccordion(item.path);
    setExpanded((prevExpanded) => !prevExpanded);
  };

  return (
    <Box sx={{ pb: 1 }}>
      {item.children ? (
        <Accordion
          ref={accordionRef}
          expanded={expanded}
          onChange={handleToggleAccordion}
          elevation={0}
          sx={{
            bgcolor: !expanded ? 'transparent' : (theme) => alpha(theme.palette.success.main, 0.20),
            boxShadow: 'none',
            borderRadius: '0.75rem',
          }}
        >
          <AccordionSummary
            expandIcon={<Icon icon="ooui:expand" />}
            sx={{
              minHeight: 55,
              borderRadius: 0.75,
              typography: 'body2',
              color: '#00a76f',
              textTransform: 'capitalize',
              fontWeight: 'fontWeightMedium',
              ...(active && {
                color: '#fff',
                fontWeight: 'fontWeightSemiBold',
                bgcolor: (theme) => alpha(theme.palette.success.dark, 1),
                '&:hover': {
                  bgcolor: (theme) => alpha(theme.palette.success.main, 1),
                },
              }),
              '&:hover': {
                bgcolor: (theme) => alpha(theme.palette.success.main, 0.1),
              },
            }}
          >
            <Box component="span" sx={{ width: 24, height: 24, mr: 2 }}>
              {item.icon}
            </Box>
            <Box component="span">{item.title}</Box>
          </AccordionSummary>
          <AccordionDetails>
            <Stack spacing={0.5} sx={{ ml: 0 }}>
              {item.children.map((childItem) => (
                <NavItem
                  key={childItem.title}
                  item={childItem}
                  setExpandedAccordion={setExpandedAccordion}
                />
              ))}
            </Stack>
          </AccordionDetails>
        </Accordion>
      ) : (
        <ListItemButton
          component={RouterLink}
          href={item.path}
          sx={{
            minHeight: 55,
            borderRadius: 0.75,
            typography: 'body2',
            color: '#00a76f',
            textTransform: 'capitalize',
            fontWeight: 'fontWeightMedium',
            ...(active && {
              color: '#fff',
              fontWeight: 'fontWeightSemiBold',
              bgcolor: (theme) => alpha(theme.palette.success.main, 1),
              '&:hover': {
                bgcolor: (theme) => alpha(theme.palette.success.main, 0.78),
              },
            }),
          }}
        >
          <Box component="span" sx={{ width: 24, height: 24, mr: 2 }}>
            {item.icon}
          </Box>
          <Box component="span">{item.title}</Box>
        </ListItemButton>
      )}
    </Box>
  );
}

NavItem.propTypes = {
  item: PropTypes.object,
  setExpandedAccordion: PropTypes.func,
};
